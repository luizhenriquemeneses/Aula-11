package com.example.home;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b01 = (Button) findViewById(R.id.bt_calcular);  {
                final EditText Consumo = (EditText) findViewById(R.id.edt_consumo);
                final EditText Couvert = (EditText) findViewById(R.id.edt_couvert_artistico);
                final EditText Dividir = (EditText) findViewById(R.id.edt_dividir);
                final EditText Taxa = (EditText) findViewById(R.id.edt_servico);
                final EditText Conta = (EditText) findViewById(R.id.edt_conta_total);
                final EditText Valor = (EditText) findViewById(R.id.edt_valor_pessoa);

            b01.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Double consum = Double.parseDouble (Consumo.getText().toString());
                    Double porcentagem = 10/100*consum;
                    Taxa.setText(**porcentagem);

                    Double conver = Double.parseDouble(Couvert.getText().toString());
                    Double Totalconta = consum + porcentagem + conver;
                    Conta.setText(**+Totalconta);

                    int divid = Integer.parseInt(Dividir.getText().toString());
                    Double ppessoa = Totalconta/divid;
                    Valor.setText(**ppessoa);
                }
            });
            }
        });


    }
}
